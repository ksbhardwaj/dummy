package com.fdmgroup.dao;

import com.fdmgroup.model.Admin;

public class AdminImp {

	
	public static void main(String[] args) {
	
		AdminDAO adminDAO = AdminDAO.getInstance();
		Admin admin = new Admin("ketan.sharma", "password");
		adminDAO.create(admin);
	}
}
