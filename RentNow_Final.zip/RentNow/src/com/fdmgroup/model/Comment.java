package com.fdmgroup.model;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "rentnow_comment")
@NamedQueries({
	@NamedQuery(name = "comment.findByPost", query = "SELECT c FROM Comment c Where post= :post"),
})
public class Comment implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="id")
	@SequenceGenerator(name="my_seq_comment", sequenceName="MY_JPA_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="my_seq_comment")
	private int id;
	
	@Column
	public String user_comment;
	
	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private User user;
	
	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private Post post;

	public Comment(String comment, User user, Post post) {
		super();
		this.user_comment = comment;
		this.user = user;
		this.post = post;
	}

	public Comment() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getComment() {
		return user_comment;
	}

	public void setComment(String comment) {
		this.user_comment = comment;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Post getPost() {
		return post;
	}

	public void setPost(Post post) {
		this.post = post;
	}

	@Override
	public String toString() {
		return "Comment [comment=" + user_comment + ", user=" + user + ", post=" + post + "]";
	}
}
