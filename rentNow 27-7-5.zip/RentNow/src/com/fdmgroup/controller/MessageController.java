package com.fdmgroup.controller;

import org.springframework.messaging.handler.annotation.DestinationVariable;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.stereotype.Controller;

@Controller
public class MessageController {
	
	@MessageMapping("/messagehandler/{teamId}")
	@SendTo("/refresh/{teamId}")
	public String refreshContent(String incMessage, @DestinationVariable int teamId){
		System.out.println("------------------------------------------------>"+incMessage);
		return incMessage;
	}
	
	@MessageMapping("/messagehandler/broadcast")
	@SendTo("/broadcast/{teamId}")
	public String messageExchange(String incMessage, @DestinationVariable int teamId){
		
		return null;
	}
}
