package com.fdmgroup.controller;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fdmgroup.dao.MessageDAO;
import com.fdmgroup.dao.UserDAO;
import com.fdmgroup.model.Message;
import com.fdmgroup.model.User;


@Controller
public class MessageToUserController {

	@RequestMapping(value="messages", method=RequestMethod.GET)
	public String Messages(Model model, HttpServletRequest req) {
		HttpSession session = req.getSession();
		User user = (User) session.getAttribute("currentUser");
		MessageDAO messageDAO = MessageDAO.getInstance();
		List<Message> msgList = messageDAO.getMessagesByRecipient(user.getUserId());
//		Set<User> senderList = new HashSet<User>();
//		UserDAO userDAO = UserDAO.getInstance();
//		for (Message message : msgList) {
//			senderList.add(userDAO.getUserByID(message.getRecipient()));
//		}
		model.addAttribute("msgList", msgList);
//		model.addAttribute("senderList", senderList);
		return "messagetouser";
	}
	
//	@RequestMapping(value="/messages", method=RequestMethod.POST)
//	public @ResponseBody List<Message> MessagesPost(HttpServletRequest req){
//		HttpSession session = req.getSession();
//		User user = (User) session.getAttribute("currentUser");
//		MessageDAO messageDAO = MessageDAO.getInstance();
//		List<Message> msgList = new ArrayList<Message>();
//		msgList = messageDAO.getMessagesByUser(user);
//		return msgList;
//	}
	
	@RequestMapping(value="/sendmessage", method=RequestMethod.POST)
	public @ResponseBody HashMap<String, String> SendMessage(HttpServletRequest req){
		HashMap<String, String> rm = new HashMap<String, String>();
		String messageBody = req.getParameter("messageBody");
		int recipientId = Integer.parseInt(req.getParameter("postUserId"));
//		UserDAO userDAO = UserDAO.getInstance();
//		User recipient = userDAO.getUserByID(recipientId);
		HttpSession session = req.getSession();
		User user = (User) session.getAttribute("currentUser");
		MessageDAO messageDAO = MessageDAO.getInstance();
		Message message = new Message();
		message.setMessage(messageBody);
		message.setRecipient(recipientId);
		message.setUser(user);
		messageDAO.create(message);
		rm.put("success", "true");
		rm.put("message", "Message sent successfully..!"); 
		return rm;
	}
	
//	@RequestMapping(value="/sendmessage", method=RequestMethod.POST)
//	public @ResponseBody HashMap<String, String> SendMessage(HttpServletRequest req){
//		HashMap<String, String> rm = new HashMap<String, String>();
//		String messageBody = req.getParameter("messageBody");
//		int postUserId = Integer.parseInt(req.getParameter("postUserId"));
//		HttpSession session = req.getSession();
//		User user = (User) session.getAttribute("currentUser");
//		MessageDAO messageDAO = MessageDAO.getInstance();
//		Message message = new Message(postUserId, messageBody, user);
//		messageDAO.create(message);
//		rm.put("success", "true");
//		rm.put("message", "Message sent successfully..!"); 
//		return rm;
//	}
}
