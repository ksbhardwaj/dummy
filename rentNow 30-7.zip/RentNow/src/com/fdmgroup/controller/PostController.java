package com.fdmgroup.controller;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.io.FileUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fdmgroup.dao.CommentDAO;
import com.fdmgroup.dao.PostDAO;
import com.fdmgroup.dao.ReportPostDAO;
import com.fdmgroup.model.Post;
import com.fdmgroup.model.ReportPost;
import com.fdmgroup.model.User;

import net.coobird.thumbnailator.Thumbnails;

@MultipartConfig(fileSizeThreshold=1024*1024*2, // 2MB
maxFileSize=1024*1024*10,      // 10MB
maxRequestSize=1024*1024*50)   // 50MB

@Controller
@RequestMapping("/post")
public class PostController {

	private String s;
	
	@RequestMapping(value="/user", method=RequestMethod.GET)
	public String ShowUserPosts(Model model, HttpServletRequest req) {
		HttpSession session = req.getSession();
		User user = (User) session.getAttribute("currentUser");
		PostDAO postDAO = PostDAO.getInstance();
		List<Post> posts = postDAO.findByUser(user);
		model.addAttribute("posts", posts);
		return "userposts";
	}
	
	@RequestMapping(value="user/{postId}", method=RequestMethod.GET)
	public String ShowUserPostGET(Model model, HttpServletRequest req, @PathVariable int postId) {
		PostDAO postDAO = PostDAO.getInstance();
		Post post = postDAO.getPostById(postId);
		CommentDAO commentDAO = CommentDAO.getInstance();
		List<com.fdmgroup.model.Comment> commentList = commentDAO.read(post);
		HttpSession session = req.getSession();
		User user = (User) session.getAttribute("currentUser");
		model.addAttribute("user", user);
		model.addAttribute("post", post);
		model.addAttribute("commentList", commentList);
		return "userpost";
	}
	
	@RequestMapping(value="user/{postId}", method=RequestMethod.POST)
	public String ShowUserPostPOST(Model model, HttpServletRequest req, @PathVariable int postId) {
		PostDAO postDAO = PostDAO.getInstance();
		Post post = postDAO.getPostById(postId);
		CommentDAO commentDAO = CommentDAO.getInstance();
		List<com.fdmgroup.model.Comment> commentList = commentDAO.read(post);
		model.addAttribute("post", post);
		model.addAttribute("commentList", commentList);
		return "userpost";
	}
	
	@RequestMapping(value="/add", method=RequestMethod.GET)
	public String AddPost(Model model, HttpServletRequest req) {
		HttpSession session = req.getSession();
		User user = (User) session.getAttribute("currentUser");
		model.addAttribute("currentUser", user);
		return "AddPost";
	}
	
	@RequestMapping(value="/add", method=RequestMethod.POST)
	public String CreatePost(Model model, HttpServletRequest request) {
		boolean isMultipart = ServletFileUpload.isMultipartContent(request);
		List<String> list = new ArrayList<String>();
        if (isMultipart) {
            // Create a factory for disk-based file items
            FileItemFactory factory = new DiskFileItemFactory();

            // Create a new file upload handler
            ServletFileUpload upload = new ServletFileUpload(factory);

            try {
                // Parse the request
                List items = upload.parseRequest(request);
                Iterator iterator = items.iterator();
                while (iterator.hasNext()) {
                    FileItem item = (FileItem) iterator.next();
                    
                    if (!item.isFormField()) {
                    	
//	                    String fileName = item.getName(); 
//	                    if (!fileName.isEmpty()) {
//	                    	ServletContext servletContext = request.getSession().getServletContext();
//	                		String root = servletContext.getRealPath("/");
//	                		File path = new File(root + "/resources/userImages/temp");
//	                		if (!path.exists()) {
//	                            boolean status = path.mkdirs();
//	                        }
//	                        long currentTime= System.currentTimeMillis();
//	                        s = String.valueOf(currentTime) + "_" + fileName;
//	                        File uploadedFile = new File(path + "/" + s);
//	                        item.write(uploadedFile);
//	                        Thumbnails.of(uploadedFile)
//	                		.size(530, 400)
//	                		.toFile(new File(root + "/resources/userImages/" + s));
//	                		FileUtils.deleteDirectory(new File(root + "/resources/userImages/temp"));
                    	String fileName = item.getName(); 
	                    if (!fileName.isEmpty()) {
	                    	ServletContext servletContext = request.getSession().getServletContext();
	                		String root = servletContext.getRealPath("/");
	                		File path = new File(root + "/resources/userImages");
	                		if (!path.exists()) {
	                            boolean status = path.mkdirs();
	                        }
	                        long currentTime= System.currentTimeMillis();
	                        s = String.valueOf(currentTime) + "_" + fileName;
	                        File uploadedFile = new File(path + "/" + s);
	                        item.write(uploadedFile);
	                    }
                    }
                    else if(item.isFormField()){
                    	list.add(item.getString());
                    }
                }
            } catch (FileUploadException e) {
                e.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        String title = list.get(0);
        String date = list.get(1);
		String category = list.get(2);
		String address = list.get(3);
		String price = list.get(4);
		String description = list.get(5);
		String image = s;
		
		HttpServletRequest httpReq= (HttpServletRequest) request;
		HttpSession session= httpReq.getSession(false);
		User user = (User) session.getAttribute("currentUser");
		
		Post post = new Post(title, date, category, address, description, image, price, 0, 0, 0, user);
		
		PostDAO postDAO = PostDAO.getInstance();
		postDAO.create(post);
		request.setAttribute("Msg", "Successful..!");
		model.addAttribute("currentUser", user);
		return "AddPost";
	}
	
	@RequestMapping(value="/addFeatured", method=RequestMethod.GET)
	public String AddFeaturedPost(Model model, HttpServletRequest req) {
		HttpSession session = req.getSession();
		User user = (User) session.getAttribute("currentUser");
		model.addAttribute("currentUser", user);
		return "AddFeaturedPost";
	}
	
	@RequestMapping(value="/addFeatured", method=RequestMethod.POST)
	public @ResponseBody HashMap<String, String> CreateFeaturedPost(Model model, HttpServletRequest request) {
		HashMap<String, String> rm = new HashMap<String, String>();
		boolean isMultipart = ServletFileUpload.isMultipartContent(request);
		List<String> list = new ArrayList<String>();
        if (isMultipart) {
            // Create a factory for disk-based file items
            FileItemFactory factory = new DiskFileItemFactory();

            // Create a new file upload handler
            ServletFileUpload upload = new ServletFileUpload(factory);

            try {
                // Parse the request
                List items = upload.parseRequest(request);
                Iterator iterator = items.iterator();
                while (iterator.hasNext()) {
                    FileItem item = (FileItem) iterator.next();
                    
                    if (!item.isFormField()) {
                    	
	                    String fileName = item.getName(); 
	                    if (!fileName.isEmpty()) {
	                    	ServletContext servletContext = request.getSession().getServletContext();
	                		String root = servletContext.getRealPath("/");
	                		File path = new File(root + "/resources/userImages");
	                		if (!path.exists()) {
	                            boolean status = path.mkdirs();
	                        }
	                        long currentTime= System.currentTimeMillis();
	                        s = String.valueOf(currentTime) + "_" + fileName;
	                        File uploadedFile = new File(path + "/" + s);
	                        item.write(uploadedFile);
	                    }
                    }
                    else if(item.isFormField()){
                    	list.add(item.getString());
                    }
                }
            } catch (FileUploadException e) {
                e.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        String title = list.get(0);
        String date = list.get(1);
		String category = list.get(2);
		String address = list.get(3);
		String price = list.get(4);
		String description = list.get(5);
		String image = s;
		
		HttpServletRequest httpReq= (HttpServletRequest) request;
		HttpSession session= httpReq.getSession(false);
		User user = (User) session.getAttribute("currentUser");
		
		Post post = new Post(title, date, category, address, description, image, price, 1, 0, 0, user);
		
		PostDAO postDAO = PostDAO.getInstance();
		postDAO.create(post);
//		request.setAttribute("Msg", "Successful..!");
//		model.addAttribute("currentUser", user);
//		return "AddFeaturedPost";
		rm.put("success", "true");
		rm.put("message", "Successful...!"); 
		return rm;
	}
	
	@RequestMapping(value="comment/{postId}", method=RequestMethod.POST)
	public String Comment(Model model, HttpServletRequest req, @PathVariable int postId) {
		PostDAO postDAO = PostDAO.getInstance();
		Post post = postDAO.getPostById(postId);
		HttpServletRequest httpReq= (HttpServletRequest) req;
		HttpSession session= httpReq.getSession(false);
		User user = (User) session.getAttribute("currentUser");
		String commentBody = req.getParameter("addComment");
		com.fdmgroup.model.Comment comment = new com.fdmgroup.model.Comment(commentBody, user, post);
		CommentDAO commentDAO = CommentDAO.getInstance();
		commentDAO.create(comment);
		return "redirect:/post/user/{postId}";
	}
	
	@RequestMapping(value="/deletepost", method=RequestMethod.POST)
	public @ResponseBody HashMap<String, String> DeletePost(Model model, HttpServletRequest request) {
		HashMap<String, String> rm = new HashMap<String, String>();
		int postId = Integer.parseInt(request.getParameter("postId"));
		PostDAO postDAO = PostDAO.getInstance();
		Post post = postDAO.getPostById(postId);
		post.setArchive(1);
		postDAO.updatePost(post);
		rm.put("success", "true");
		rm.put("message", "Successful...!"); 
		return rm;
	}
	
	@RequestMapping(value="spam/{postid}", method=RequestMethod.POST)
	public @ResponseBody HashMap<String, String> submitSpam(Model model, HttpServletRequest req, @PathVariable int postid) {
		HashMap<String, String> rm = new HashMap<String, String>();
		ReportPostDAO reportpostDAO = ReportPostDAO.getInstance();
		if(reportpostDAO.findById(postid).isEmpty()){
		ReportPost post = new ReportPost(postid);
		reportpostDAO.create(post);
		}
		rm.put("success", "true");
		rm.put("message", "Successful...!"); 
		return rm;
	}
	
	@RequestMapping(value="report/{postid}", method=RequestMethod.POST)
	public @ResponseBody HashMap<String, String> repostPost(Model model, HttpServletRequest req, @PathVariable int postid) {
		HashMap<String, String> rm = new HashMap<String, String>();
		PostDAO postDAO = PostDAO.getInstance();
		Post post = postDAO.getPostById(postid);
		post.setBan(1);
		postDAO.updatePost(post);
		ReportPostDAO reportpostDAO = ReportPostDAO.getInstance();
		ReportPost reportpost = reportpostDAO.findpostById(postid);
		reportpostDAO.delete(reportpost);
		rm.put("success", "true");
		rm.put("message", "Successful...!"); 
		return rm;
	}
	
	class ReturnMessage{
		boolean success;
		String message;
		
		public boolean isSuccess() {
			return success;
		}
		public void setSuccess(boolean success) {
			this.success = success;
		}
		public String getMessage() {
			return message;
		}
		public void setMessage(String message) {
			this.message = message;
		}
		public ReturnMessage(boolean success, String message){
			this.success = success;
			this.message = message;
		} 
	}
}
