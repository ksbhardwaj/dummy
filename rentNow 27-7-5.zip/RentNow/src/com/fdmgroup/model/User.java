package com.fdmgroup.model;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.lambdaworks.crypto.SCryptUtil;

@Entity
@Table(name = "rentnow_user")
@NamedQueries({
	@NamedQuery (name = "allUser", query = "SELECT us FROM User us"),
	@NamedQuery (name = "oneUserUsernameOnly", query = "SELECT us FROM User us WHERE us.username = :username_in"),
	@NamedQuery (name = "oneUserEmailOnly", query = "SELECT us FROM User us WHERE us.email = :email_in"),
	@NamedQuery (name = "oneUserIDOnly", query = "SELECT us FROM User us WHERE us.userId = :id_in")
})
public class User implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="id")
	@SequenceGenerator(name="my_seq_user", sequenceName="MY_JPA_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="my_seq_user")
	private int userId;
	
	@Column(name = "username", nullable = false, unique = true)
	private String username;
	
	@Column(name = "password", nullable = false)
	private String password;
	
	@Column(name = "firstname")
	private String firstname;
	
	@Column(name = "lastname")
	private String lastname;
	
	@Column(name = "email", nullable = false, unique = true)
	private String email;
	
	@Column(name="flag")
	private int flag;
	
	@Column(name = "avatar", length = 1000)
	private String avatar;
	
	@Column(name = "secretQuestion", length = 200, nullable = false)
	private String secretQuestion;
	
	@Column(name = "secretAnswer", length = 200, nullable = false)
	private String secretAnswer;
	
	@OneToMany(mappedBy = "user")
	private List<Post> posts;
	
	@OneToMany(mappedBy = "user")
	private List<Comment> comments;
	
	@JsonIgnore
	@OneToMany(mappedBy = "user")
	private List<Message> messages;
	
	public List<Message> getMessages() {
		return messages;
	}

	public void setMessages(List<Message> messages) {
		this.messages = messages;
	}

	public int getUserId() {
		return userId;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = SCryptUtil.scrypt(password, 16384, 8, 1);
	}

	public int getFlag() {
		return flag;
	}

	public void setFlag(int flag) {
		this.flag = flag;
	}

	public List<Post> getPosts() {
		return posts;
	}

	public void setPosts(List<Post> posts) {
		this.posts = posts;
	}

	public List<Comment> getComments() {
		return comments;
	}

	public void setComments(List<Comment> comments) {
		this.comments = comments;
	}

	public String getAvatar() {
		return avatar;
	}

	public void setAvatar(String avatar) {
		this.avatar = avatar;
	}

	public String getSecretQuestion() {
		return secretQuestion;
	}

	public void setSecretQuestion(String secretQuestion) {
		this.secretQuestion = secretQuestion;
	}

	public String getSecretAnswer() {
		return secretAnswer;
	}

	public void setSecretAnswer(String secretAnswer) {
		this.secretAnswer = secretAnswer;
	}

	public User() {
		super();
	}

	public User(String username, String password, String firstname, String lastname, String email, int flag,
			String avatar, String secretQuestion, String secretAnswer) {
		super();
		this.username = username;
		this.password = password;
		this.firstname = firstname;
		this.lastname = lastname;
		this.email = email;
		this.flag = flag;
		this.avatar = avatar;
		this.secretQuestion = secretQuestion;
		this.secretAnswer = secretAnswer;
	}

	@Override
	public String toString() {
		return "User [firstname=" + firstname + ", lastname=" + lastname + ", username=" + username + ", email=" + email
				+ ", password=" + password + ", flag=" + flag + ", avatar=" + avatar + "]";
	}
	
}
