package com.fdmgroup.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.fdmgroup.dao.UserDAO;
import com.fdmgroup.model.User;

@Controller
public class RegistrationController {
	
//	@Autowired
	private UserDAO userDao = UserDAO.getInstance();

	
	
	@RequestMapping(value="/register", method=RequestMethod.GET)
	public String showRegister(Model model){
		model.addAttribute("currentUser", new User());
		return "register";		
	}
	
	@RequestMapping(value="/register", method=RequestMethod.POST)
	public String processRegister(Model model, @Valid @ModelAttribute(value="currentUser") User userRegister, BindingResult br, HttpServletRequest request){
		
		if(br.hasErrors())
			return "register";
		
		String username = userRegister.getUsername();
		String password = userRegister.getPassword();
		String passwordConfirmation = request.getParameter("passwordConfirmation");
		String firstName = userRegister.getFirstname();
		String lastName = userRegister.getLastname();
		String email = userRegister.getEmail();
		String secretQuestion = userRegister.getSecretQuestion();
		String secretAnswer = userRegister.getSecretAnswer();
		
		userRegister.setAvatar("default-avatar.png");
		
				
		User user1 = userDao.getUserUsername(username);
		User user2 = userDao.getUserEmail(email);
		
		if (username.matches("^.*[^a-zA-Z0-9].*$")) {
			request.setAttribute("errorMsg", "Invalid username !!");
			model.addAttribute("currentUser", new User());
			return "register";
		}
		else if (user1 != null) {
			request.setAttribute("errorMsg", "User with username \""+ username +"\" already exists !!");
			model.addAttribute("currentUser", new User());
			return "register";
		}
		else if (user2 != null) {
			request.setAttribute("errorMsg", "User with email \""+ email +"\" already exists !!");
			model.addAttribute("currentUser", new User());
			return "register";
		}
		else if (!userDao.comparePassword(passwordConfirmation, password)) {
			request.setAttribute("errorMsg", "Passwords MUST match !!");
			model.addAttribute("currentUser", new User());
			return "register";
		}
		else {
			userDao.createUser(userRegister);
			model.addAttribute("currentUser", null);
			model.addAttribute("userRegister", null);
			HttpSession session = request.getSession();
			session.removeAttribute("currentUser");
			session.invalidate();
			request.setAttribute("Msg", "Registration Successful !");
			return "/login";	
		}		
	}
}
