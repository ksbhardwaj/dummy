var stompClient = null;

function setConnected(connected) {
//    $("#connect").prop("disabled", connected);
//    $("#disconnect").prop("disabled", !connected);
//    if (connected) {
//        $("#conversation").show();
//    }
//    else {
//        $("#conversation").hide();
//    }
//    $("#greetings").html("");
}

function connectSocket() {
    var socket = new SockJS('../planner-websocket');
    stompClient = Stomp.over(socket);
    stompClient.connect({}, function () {
//        setConnected(true);
        stompClient.subscribe('/refresh/'+$(".board-header").attr("data-team-id"), function (toRefresh) {
        	var args = toRefresh.body.split(",");
        	if(args[0]=="updateAssignmentModal"){
        		id = args[1];
        		teamId = args[2];  
        		$.post("../task/userstoassign/" + id, {teamId: teamId}, function(responseData) {
    				var iHTML = assignmentButtonsHTML(responseData);
    				$('#dropdown-menu-membership').html(iHTML);
    			});
    			$.post("../task/usersassigned/" + id, {teamId: teamId}, function(responseData) {
    				var iHTML = assignmentAvatarsHTML(responseData);
    				$('#members-wrapper').html(iHTML);
    			});
        	}
        	
        	if(args[0]=="updateTeam"){
        		updateTeam();
        	}
        	
        	if(args[0]=="refresh"){
        		location.reload();
        	}
        });
    });
}

function disconnectSocket() {
    if (stompClient != null) {
        stompClient.disconnect();
    }
//    setConnected(false);
    console.log("Disconnected");
}

function sendSocketMessage(toRefresh) {
    stompClient.send("/message/messagehandler/"+$(".board-header").attr("data-team-id"), {}, toRefresh);
}

$(function () {
//    $("form").on('submit', function (e) {
//        e.preventDefault();
//    });
//    $( "#connect" ).click(function() { connect(); });
//    $( "#disconnect" ).click(function() { disconnect(); });
//    $( "#send" ).click(function() { sendName(); });
//	$("#header-logo").click(function() {connect();});
//	$("#menu-button").click(function() {sendMessage();});
});



