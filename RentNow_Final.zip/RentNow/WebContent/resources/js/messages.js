

function sendMessage(recipient){
	$('#recipientId').html(recipient);
	$('#messageModal').modal('show');
}
$(document).ready(function() {
	connectSocket();
	
	$("#submitMessage").click(function(e){
		e.preventDefault();
		$.post("sendmessage",
			{
			messageBody: $("textarea#addMessage").val().toString(),
			postUserId: $("#recipientId").html()
			}, function(responseData) {
					
			if(responseData.success == "true"){
				$('#messageForm')[0].reset();
				$('#messageModal').modal('hide');
				alert(responseData.message);
				sendSocketMessage("Message recieved");
				//location.reload();
			}
			else{
				alert("Something wrong happened..!");
				$('#messageModal').modal('hide');
			}
		});
	});
});

//$(document).ready(function() {	
//	$(".message-panel").on("click", ".message-body", function() {
//		var id = $(this).attr("data-id");
//		$.get("messages",
//				{}, function(msgList){
//			$('.chat-panel').html('');	
//			for(i=0; i<msgList.length; i++){
//				if(msgList[i].sender == id){
//					$('.chat-panel').append('<p>'+ msgList[i].message +'</p>');
//				}
//			}
//		});
//	});
//});