package com.fdmgroup.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.fdmgroup.dao.CommentDAO;
import com.fdmgroup.dao.PostDAO;
import com.fdmgroup.dao.UserDAO;
import com.fdmgroup.model.Post;
import com.fdmgroup.model.User;

@Controller
@RequestMapping("/")
public class IndexController {

	private UserDAO userDAO = UserDAO.getInstance();
	
	@RequestMapping(method=RequestMethod.GET)
	public String IndexPage(Model model, HttpServletRequest req) {
		HttpSession session = req.getSession(false);
		if (session==null || session.getAttribute("currentUser")==null) {
			PostDAO postDAO = PostDAO.getInstance();
			List<Post> posts = postDAO.read();
			List<Post> featuredPosts = postDAO.findFeaturedPosts();
			model.addAttribute("featuredPosts", featuredPosts);
			model.addAttribute("posts", posts);
			return "index";
		}
		else if (session.getAttribute("currentUser")!=null) {
			// Update the user object
			User user = (User) session.getAttribute("currentUser");
			User foundUser = userDAO.getUserUsername(user.getUsername());
			
			// Sanity check
			if(foundUser != null && foundUser.getPassword().equals(user.getPassword())){
				session.setAttribute("currentUser", foundUser);
				return "redirect:/dashboard";
			}
		}
		
		PostDAO postDAO = PostDAO.getInstance();
		List<Post> posts = postDAO.read();
		List<Post> featuredPosts = postDAO.findFeaturedPosts();
		model.addAttribute("featuredPosts", featuredPosts);
		model.addAttribute("posts", posts);
		return "index";
	}
	
	@RequestMapping(value="/search", method=RequestMethod.GET)
	public String Search(Model model, HttpServletRequest req) {
		String location = req.getParameter("txtPlaces");
		String date = req.getParameter("datepicker");
		PostDAO postDAO = PostDAO.getInstance();
		List<Post> posts = postDAO.postSearch(date, location);
		model.addAttribute("posts", posts);
		return "index";
	}
	
	@RequestMapping(value="/{postId}", method=RequestMethod.GET)
	public String ShowPost(Model model, HttpServletRequest req, @PathVariable int postId) {
		PostDAO postDAO = PostDAO.getInstance();
		Post post = postDAO.getPostById(postId);
		CommentDAO commentDAO = CommentDAO.getInstance();
		List<com.fdmgroup.model.Comment> commentList = commentDAO.read(post);
		model.addAttribute("post", post);
		model.addAttribute("commentList", commentList);
		return "post";
	}
}
