package com.fdmgroup.dao;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.TypedQuery;
import com.fdmgroup.model.Post;
import com.fdmgroup.model.User;

public class PostDAO {

private EntityManager em;
	
	private static final PostDAO postDAO = new PostDAO();
		
	private PostDAO() {
		init();
	}
	
	public static PostDAO getInstance(){
		return postDAO;
	}
	
	public void init(){
		em = DAO.getInstance().getEntityManager();
	}
	
	public void create(Post t) {
		EntityTransaction et = em.getTransaction();
		et.begin();
		em.persist(t);
		et.commit();
	}
	
	public List<Post> read() {
		TypedQuery<Post> query = em.createNamedQuery("post.findAll", Post.class);
		return query.getResultList();
	}
	
	public List<Post> findFeaturedPosts() {
		TypedQuery<Post> query = em.createNamedQuery("post.featured", Post.class);
		return query.getResultList();
	}
	
	public List<Post> findByUser(User user)
	{
		TypedQuery<Post> query = em.createNamedQuery("post.findByUser", Post.class);
		query.setParameter("user", user);
		return query.getResultList();
	}
	
	public Post getPostById(int id){
		try {
			TypedQuery<Post> query = em.createNamedQuery("post.findPostById", Post.class);
			query.setParameter("id", id);
			return query.getSingleResult();
		} catch (Exception e) {
			return null;
		}	
	}
	
	public List<Post> postSearch(String date, String address, String minPrice, String maxPrice){
			TypedQuery<Post> query = em.createNamedQuery("post.search", Post.class);
			query.setParameter("date", "%"+date+"%");
			query.setParameter("address", "%"+address+"%");
			query.setParameter("minPrice", minPrice);
			query.setParameter("maxPrice", maxPrice);
			return query.getResultList();	
	}
	
	public void updatePost(Post post){
			em.getTransaction().begin();
			em.merge(post);
			em.getTransaction().commit();
	}
}
