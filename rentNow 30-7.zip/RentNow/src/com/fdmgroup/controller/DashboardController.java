package com.fdmgroup.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.fdmgroup.dao.PostDAO;
import com.fdmgroup.dao.UserDAO;
import com.fdmgroup.model.Post;
import com.fdmgroup.model.User;

@Controller
@RequestMapping("/dashboard")
public class DashboardController {

	private UserDAO userDAO = UserDAO.getInstance();
	
	@RequestMapping(method=RequestMethod.GET)
	public String DashboardGet(Model model, HttpServletRequest req) {
		
		HttpSession session = req.getSession();
		User user;
		
		if (session==null || session.getAttribute("currentUser")==null) {
			return "redirect:/";
		} else {
			user = (User) session.getAttribute("currentUser");

			User foundUser = userDAO.getUserUsername(user.getUsername());
			
			if(foundUser!=null && foundUser.getPassword().equals(user.getPassword())){
				PostDAO postDAO = PostDAO.getInstance();
				List<Post> posts = postDAO.read();
				List<Post> featuredPosts = postDAO.findFeaturedPosts();
				model.addAttribute("featuredPosts", featuredPosts);
				model.addAttribute("currentUser", foundUser);
				model.addAttribute("posts", posts);
				return "Dashboard";
			} else {
				return "redirect:/";
			}
		}
	}
	
	@RequestMapping(value="/search", method=RequestMethod.POST)
	public String Search(Model model, HttpServletRequest req) {
		String location = req.getParameter("txtPlaces");
		String date = req.getParameter("datepicker");
		String minPrice = req.getParameter("txtMinPrice");
		String maxPrice = req.getParameter("txtManPrice");
		PostDAO postDAO = PostDAO.getInstance();
		List<Post> posts = postDAO.postSearch(date, location, minPrice, maxPrice);
		model.addAttribute("posts", posts);
		return "usersearch";
	}
}
