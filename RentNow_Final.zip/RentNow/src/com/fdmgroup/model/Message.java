package com.fdmgroup.model;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "rentnow_message")
@NamedQueries({
	@NamedQuery(name = "message.findByUser", query = "SELECT msg FROM Message msg WHERE msg.user = :user"),
	@NamedQuery(name = "message.findByRecipient", query = "SELECT msg FROM Message msg WHERE msg.recipient = :recipient OR msg.user= :user")
})
public class Message implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="id")
	@SequenceGenerator(name="my_seq_message", sequenceName="MY_JPA_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="my_seq_message")
	private int id;
	
	@Column(name="recipient", nullable=false)
	private int recipient;
	
	@Column(name="message", length=50, nullable=false)
	private String message;
	
	@JsonIgnore
	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private User user;

	public Message() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Message(int recipient, String message, User user) {
		super();
		this.recipient = recipient;
		this.message = message;
		this.user = user;
	}

	public int getId() {
		return id;
	}

	public int getRecipient() {
		return recipient;
	}

	public void setRecipient(int recipient) {
		this.recipient = recipient;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	@Override
	public String toString() {
		return "Message [recipient=" + recipient + ", message=" + message + ", user=" + user + "]";
	}
}
