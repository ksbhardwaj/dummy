package com.fdmgroup.dao;

import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.TypedQuery;
import com.fdmgroup.model.Message;
import com.fdmgroup.model.Post;
import com.fdmgroup.model.User;

public class MessageDAO {

private EntityManager em;
	
	private static final MessageDAO messageDAO = new MessageDAO();
		
	private MessageDAO() {
		init();
	}
	
	public static MessageDAO getInstance(){
		return messageDAO;
	}
	
	public void init(){
		em = DAO.getInstance().getEntityManager();
	}
	
	public void create(Message t) {
		EntityTransaction et = em.getTransaction();
		et.begin();
		em.persist(t);
		et.commit();
	}
	
	public List<Message> getMessagesByUser(User user) {
		TypedQuery<Message> query = em.createNamedQuery("message.findByUser", Message.class);
		query.setParameter("user", user);
		return query.getResultList();
	}
	
	public List<Message> getMessagesByRecipient(int id, User user) {
		TypedQuery<Message> query = em.createNamedQuery("message.findByRecipient", Message.class);
		query.setParameter("recipient", id);
		query.setParameter("user", user);
		return query.getResultList();
	}
}
