package com.fdmgroup.model;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "rentnow_talktoadmin")
public class TalkToAdmin implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="id")
	@SequenceGenerator(name="my_seq_talk", sequenceName="MY_JPA_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="my_seq_talk")
	private int id;
	
	@Column(name="message", length=500, nullable=false)
	private String message;
	
	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private User user;

	public TalkToAdmin() {
		super();
		// TODO Auto-generated constructor stub
	}

	public TalkToAdmin(String message, User user) {
		super();
		this.message = message;
		this.user = user;
	}

	public int getId() {
		return id;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	@Override
	public String toString() {
		return "TalkToAdmin [message=" + message + ", user=" + user + "]";
	}
	
	
}
