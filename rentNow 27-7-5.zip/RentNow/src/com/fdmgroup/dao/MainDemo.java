package com.fdmgroup.dao;

import com.fdmgroup.model.Comment;
import com.fdmgroup.model.Post;
import com.fdmgroup.model.User;

public class MainDemo {

	public static void main(String[] args) {
		
		UserDAO userDao = UserDAO.getInstance();
		
		//User user = new User("Ketan","Sharma","ksb","email","1234",0);
		//userDao.create(user);
		
//		PostAddress address = new PostAddress("dfgd","dfgr","dgev","e4rf");
//		Post post = new Post("rf","dfgfdg","fgd","egr",0,address,user);
//		PostDAO postDao = new PostDAO();
//		postDao.create(post);
//		
//		Comment comment = new Comment("comment",user,post);
//		CommentDAO commentDao = new CommentDAO();
//		commentDao.create(comment);
	}

}
