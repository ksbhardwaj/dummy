$(document).ready(function() {
	$('#paypal-button-container').hide();
	$("#featuredPost").click(function(e){
		e.preventDefault();
		if( $('#pac-input').val() == "" || $('#description').val() == "" || $('#image').val() == ""){
			alert('Fill out all the fields!');
		}
		else{
			alert('Click on the checkout button to make the payment')
			$("#featuredPost").hide();
			$('#paypal-button-container').show();
		}
	});
});

paypal.Button.render({

            env: 'sandbox', // sandbox | production

            // PayPal Client IDs - replace with your own
            // Create a PayPal app: https://developer.paypal.com/developer/applications/create
            client: {
            	 sandbox:    'AZDxjDScFpQtjWTOUtWKbyN_bDt4OgqaF4eYXlewfBP4-8aqX3PiV8e1GWU6liB2CUXlkA59kJXE7M6R',
                 production: 'payment@rentnow.com'
            },

            // Show the buyer a 'Pay Now' button in the checkout flow
            commit: true,

            // payment() is called when the button is clicked
            payment: function(data, actions) {

                // Make a call to the REST api to create the payment
                return actions.payment.create({
                    payment: {
                        transactions: [
                            {
                                amount: { total: '1.99', currency: 'CAD' }
                            }
                        ]
                    }
                });
            },

            // onAuthorize() is called when the buyer approves the payment
            onAuthorize: function(data, actions) {

                // Make a call to the REST api to execute the payment
               return actions.payment.execute().then(function() {
                $(document).ready(function() {
//                	$('#featuredPostForm').submit(function( e ) {
                	console.log(new FormData($('#featuredPostForm')[0]));
              	    $.ajax({
              	      url: '../post/addFeatured',
              	      type: 'POST',
              	      data: new FormData($('#featuredPostForm')[0]),
              	      processData: false,
              	      contentType: false,
              	      success: function(responseData){
              	    	  $('#featuredPostForm')[0].reset();
              	    	  $("#featuredPost").show();
              	    	  $('#paypal-button-container').hide();
              	    	  alert(responseData.message);
              	      }
              	    });
              	    //e.preventDefault();
//              	  });
                });
               });
            }

        }, '#paypal-button-container');