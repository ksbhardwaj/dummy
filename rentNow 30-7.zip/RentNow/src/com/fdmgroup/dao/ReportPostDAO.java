package com.fdmgroup.dao;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.TypedQuery;
import com.fdmgroup.model.Post;
import com.fdmgroup.model.ReportPost;
import com.fdmgroup.model.User;

public class ReportPostDAO {

private EntityManager em;
	
	private static final ReportPostDAO reportpostDAO = new ReportPostDAO();
		
	private ReportPostDAO() {
		init();
	}
	
	public static ReportPostDAO getInstance(){
		return reportpostDAO;
	}
	
	public void init(){
		em = DAO.getInstance().getEntityManager();
	}
	
	public void create(ReportPost t) {
		EntityTransaction et = em.getTransaction();
		et.begin();
		em.persist(t);
		et.commit();
	}
	
	public List<ReportPost> read() {
		TypedQuery<ReportPost> query = em.createNamedQuery("reportpost.findAll", ReportPost.class);
		return query.getResultList();
	}
	
	public void delete(ReportPost post){
		EntityTransaction et = em.getTransaction();
		et.begin();
		em.remove(post);
		et.commit();
	}
	
	public List<ReportPost> findById(int postid){
		TypedQuery<ReportPost> query = em.createNamedQuery("reportpost.findById", ReportPost.class);
		query.setParameter("postid", postid);
		return query.getResultList();
	}
	
	public ReportPost findpostById(int postid){
		TypedQuery<ReportPost> query = em.createNamedQuery("reportpost.findById", ReportPost.class);
		query.setParameter("postid", postid);
		return query.getSingleResult();
	}
}
