package com.fdmgroup.controller;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.fdmgroup.dao.UserDAO;
import com.fdmgroup.model.User;

import net.coobird.thumbnailator.Thumbnails;

@Controller
//@RequestMapping(value="/updateProfile")
public class UpdateProfileController {

	
	private static Logger updateProfileLogger = Logger.getLogger("appLogger");
	
	private UserDAO userDao = UserDAO.getInstance();
	
	private String s;
	
	
	@RequestMapping(value="/profile", method=RequestMethod.GET)
	public String showProfile(Model model, HttpServletRequest request){
		
//		User currentUser = (User) request.getSession().getAttribute("currentUser");
//		model.addAttribute("currentUser", currentUser);
		
		return "profile";		
	}
	
	
	@RequestMapping(value="/changePassword", method=RequestMethod.GET)
	public String changePassword(Model model, HttpServletRequest request){
		
//		User currentUser = (User) request.getSession().getAttribute("currentUser");
//		model.addAttribute("currentUser", currentUser);
		
		return "changePassword";		
	}
	
	
	@RequestMapping(value="/changePassword", method=RequestMethod.POST)
	public String changePassword(Model model, @RequestParam String currentPass, @RequestParam String newPass, @RequestParam String newPassConf, HttpServletRequest request){
		
		User currentUser = (User) request.getSession().getAttribute("currentUser");

		
		
		if(!userDao.comparePassword(currentPass, currentUser.getPassword())){
			updateProfileLogger.info("Unsuccessful password update attempt (wrong password) with username: " + currentUser.getUsername());
			request.setAttribute("errorMsg", "Invalid Current Password !");
			return "changePassword";
		}
		else if(!newPass.equals(newPassConf)){
			updateProfileLogger.info("Unsuccessful password update attempt () with username: " + currentUser.getUsername());
			request.setAttribute("errorMsg", " New Password and Password Confirmation MUST match !");
			return "changePassword";
		}
		

		
		
		currentUser.setPassword(newPass);
		userDao.updateUser(currentUser);
		model.addAttribute("currentUser", currentUser);
		updateProfileLogger.info("Successful password update with username: " + currentUser.getUsername());
		return "redirect:/";
		
		
		
	}	
	
	
	
	@RequestMapping(value="/updateProfile", method=RequestMethod.POST)
	public String updateProfile(Model model, HttpServletRequest request, HttpServletResponse response){
		
		boolean isMultipart = ServletFileUpload.isMultipartContent(request);
		List<String> list = new ArrayList<String>();
        if (isMultipart) {
            // Create a factory for disk-based file items
            FileItemFactory factory = new DiskFileItemFactory();

            // Create a new file upload handler
            ServletFileUpload upload = new ServletFileUpload(factory);

            
            try {
                // Parse the request
                List items = upload.parseRequest(request);
                Iterator iterator = items.iterator();

                while (iterator.hasNext()) {
                	
                    FileItem item = (FileItem) iterator.next();
                    if (!item.isFormField()) {
                    	
                    	String fileName = item.getName();
                    	
                    	if (!fileName.isEmpty()) {
                    		ServletContext servletContext = request.getSession().getServletContext();
                    		String root = servletContext.getRealPath("/");
                    		File path = new File(root + "/resources/Avatars/temp");
                    		if (!path.exists()) {
                    			boolean status = path.mkdirs();
                    		}
                    		long currentTime= System.currentTimeMillis();
                    		s = String.valueOf(currentTime) + "_" + fileName;
                    		File uploadedFile = new File(path + "/" + s);
                    		item.write(uploadedFile);
                    		Thumbnails.of(uploadedFile)
                    		.size(160, 160)
                    		.toFile(new File(root + "/resources/Avatars/" + s));
                    		FileUtils.deleteDirectory(new File(root + "/resources/Avatars/temp"));
                    	}
                    }
                    else if(item.isFormField()){
                        list.add(item.getString());
                    }
                }
            } catch (FileUploadException e) {
                e.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        
        String firstname = list.get(0);
        String lastname = list.get(1);
        String username = list.get(2);
        String email = list.get(3);
        String secretQuestion = list.get(4);
        String secretAnswer = list.get(5);
        String image = s;

		User currentUser = (User) request.getSession().getAttribute("currentUser");
		
		User user1 = null;
		User user2 = null;
		
		if (!currentUser.getUsername().equals(username))
			user1 = userDao.getUserUsername(username);
		
		if (!currentUser.getEmail().equals(email))
			user2 = userDao.getUserEmail(email);
		
		if (username.matches("^.*[^a-zA-Z0-9].*$")) {
			request.setAttribute("errorMsg", "Invalid username !!");
			return "profile";
		}
		else if (user1 != null) {
			request.setAttribute("errorMsg", "User with username \""+ username +"\" already exists !!");
			return "profile";
		}
		else if (user2 != null) {
			request.setAttribute("errorMsg", "User with email \""+ email +"\" already exists !!");
			return "profile";
		}
		
		
		currentUser.setUsername(username);
		currentUser.setEmail(email);
		currentUser.setSecretQuestion(secretQuestion);
		currentUser.setSecretAnswer(secretAnswer);
		if (firstname != null)
				currentUser.setFirstname(firstname);
		if (lastname != null)
			currentUser.setLastname(lastname);
		if (image != null)
			currentUser.setAvatar(image);
		
		
		userDao.updateUser(currentUser);
		model.addAttribute("currentUser", currentUser);
		request.setAttribute("Msg", "Profile Updated Successfully !!");
		updateProfileLogger.info("Successful profile update with username: " + currentUser.getUsername());
		return "profile";
	}
}
