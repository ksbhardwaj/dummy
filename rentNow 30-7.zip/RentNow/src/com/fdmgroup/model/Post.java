package com.fdmgroup.model;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "rentnow_post")
@NamedQueries({
	@NamedQuery(name = "post.findAll", query = "SELECT p FROM Post p WHERE p.featured=0 AND p.ban=0 AND p.archive=0"),
	@NamedQuery(name = "post.findByUser", query = "SELECT p FROM Post p WHERE p.user = :user AND p.ban=0 AND p.archive=0"),
	@NamedQuery(name = "post.findPostById", query = "SELECT p FROM Post p WHERE p.id = :id AND p.ban=0 AND p.archive=0"),
	@NamedQuery(name = "post.search", query = "SELECT p FROM Post p WHERE p.address LIKE :address OR p.availableDate LIKE :date OR p.price >= :minPrice OR p.price <= :maxPrice AND p.ban=0 AND p.archive=0"),
	@NamedQuery(name = "post.featured", query = "SELECT u FROM Post u WHERE featured=1 AND ban=0 AND archive=0")
})
public class Post implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="id")
	@SequenceGenerator(name = "my_seq_post", sequenceName="MY_JPA_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="my_seq_post")
	private int id;
	
	@Column(name="title", nullable=false)
	private String title;
	
	@Column(name="availabledate", length=50, nullable=false)
	private String availableDate;
	
	@Column(name="type", length=50, nullable=false)
	private String type;
	
	@Column(name="address", length=200, nullable=false)
	private String address;
	
	@Column(name="description", length=2000, nullable=false)
	private String description;
	
	@Column(name="imagepath", length=200, nullable=false)
	private String imagePath;
	
	@Column(name="price", nullable=false)
	private String price;
	
	@Column(name="featured")
	private int featured;
	
	@Column(name="archive")
	private int archive;
	
	@Column(name="ban")
	private int ban;
	
	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private User user;
	
	@OneToMany(mappedBy = "post")
	private List<Comment> comments;

	public Post() {
		super();
	}
	

	public Post(String title, String availableDate, String type, String address, String description, String imagePath,
			String price, int featured, int archive, int ban, User user) {
		super();
		this.title = title;
		this.availableDate = availableDate;
		this.type = type;
		this.address = address;
		this.description = description;
		this.imagePath = imagePath;
		this.price = price;
		this.featured = featured;
		this.archive = archive;
		this.ban = ban;
		this.user = user;
	}


	public int getId() {
		return id;
	}

	public String getAvailableDate() {
		return availableDate;
	}

	public void setAvailableDate(String availableDate) {
		this.availableDate = availableDate;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getImagePath() {
		return imagePath;
	}

	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}

	public int getFeatured() {
		return featured;
	}

	public void setFeatured(int featured) {
		this.featured = featured;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public List<Comment> getComments() {
		return comments;
	}

	public void setComments(List<Comment> comments) {
		this.comments = comments;
	}
	

	public String getPrice() {
		return price;
	}



	public void setPrice(String price) {
		this.price = price;
	}



	public int getArchive() {
		return archive;
	}



	public void setArchive(int archive) {
		this.archive = archive;
	}



	public int getBan() {
		return ban;
	}



	public void setBan(int ban) {
		this.ban = ban;
	}

	public String getTitle() {
		return title;
	}


	public void setTitle(String title) {
		this.title = title;
	}


	@Override
	public String toString() {
		return "Post [availableDate=" + availableDate + ", type=" + type + ", address=" + address + ", description="
				+ description + ", imagePath=" + imagePath + ", featured=" + featured + "]";
	}

	
}
