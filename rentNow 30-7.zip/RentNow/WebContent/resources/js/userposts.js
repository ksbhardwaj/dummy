function deletePost(postid) {
	var id = postid;
	$.post('deletepost',
			{postId: id}, function(responseData) {
				
		if(responseData){
			location.reload();
		}
	});
}