package com.fdmgroup.model;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "rentnow_post")
@NamedQueries({
	@NamedQuery(name = "post.findAll", query = "SELECT u FROM Post u WHERE flag=0"),
	@NamedQuery(name = "post.findByUser", query = "SELECT u FROM Post u WHERE u.user = :user"),
	@NamedQuery(name = "post.findPostById", query = "SELECT p FROM Post p WHERE p.id = :id"),
	@NamedQuery(name = "post.search", query = "SELECT p FROM Post p WHERE p.address LIKE :address OR availableDate LIKE :date"),
	@NamedQuery(name = "post.featured", query = "SELECT u FROM Post u WHERE flag=1")
})
public class Post implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="id")
	@SequenceGenerator(name = "my_seq_post", sequenceName="MY_JPA_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="my_seq_post")
	private int id;
	
	@Column(name="availabledate", length=50, nullable=false)
	private String availableDate;
	
	@Column(name="type", length=50, nullable=false)
	private String type;
	
	@Column(name="address", length=200, nullable=false)
	private String address;
	
	@Column(name="description", length=2000, nullable=false)
	private String description;
	
	@Column(name="imagepath", length=200, nullable=false)
	private String imagePath;
	
	@Column(name="flag")
	private int flag;
	
	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private User user;
	
	@OneToMany(mappedBy = "post")
	private List<Comment> comments;

	public Post() {
		super();
	}

	public Post(String availableDate, String type, String address, String description, String imagePath, int flag,
			User user) {
		super();
		this.availableDate = availableDate;
		this.type = type;
		this.address = address;
		this.description = description;
		this.imagePath = imagePath;
		this.flag = flag;
		this.user = user;
	}

	public int getId() {
		return id;
	}

	public String getAvailableDate() {
		return availableDate;
	}

	public void setAvailableDate(String availableDate) {
		this.availableDate = availableDate;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getImagePath() {
		return imagePath;
	}

	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}

	public int getFlag() {
		return flag;
	}

	public void setFlag(int flag) {
		this.flag = flag;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public List<Comment> getComments() {
		return comments;
	}

	public void setComments(List<Comment> comments) {
		this.comments = comments;
	}

	@Override
	public String toString() {
		return "Post [availableDate=" + availableDate + ", type=" + type + ", address=" + address + ", description="
				+ description + ", imagePath=" + imagePath + ", flag=" + flag + "]";
	}

	
}
