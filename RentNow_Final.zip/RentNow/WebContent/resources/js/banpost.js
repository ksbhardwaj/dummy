//$(document).ready(function() {
//	$('#ban-post').click(function(e){
//		e.preventDefault();
	function banpost(postid){
		var id = postid;
		$.post("post/report/" + id,
				{}, function(responseData) {
			if(responseData.success == "true"){
				alert(responseData.message);
				location.reload();
			}
		});
	}
//		
//	});
//});