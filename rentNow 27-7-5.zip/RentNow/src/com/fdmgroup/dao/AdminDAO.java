package com.fdmgroup.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.TypedQuery;

import com.fdmgroup.model.Admin;

public class AdminDAO{

private EntityManager em;
	
	private static final AdminDAO adminDAO = new AdminDAO();
		
	private AdminDAO() {
		init();
	}
	
	public static AdminDAO getInstance(){
		return adminDAO;
	}
	
	public void init(){
		em = DAO.getInstance().getEntityManager();
	}
	
	public void create(Admin t) {
		EntityTransaction et = em.getTransaction();
		et.begin();
		em.persist(t);
		et.commit();
	}

}
