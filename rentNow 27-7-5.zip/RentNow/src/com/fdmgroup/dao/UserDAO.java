package com.fdmgroup.dao;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.NoResultException;
import javax.persistence.TypedQuery;

import com.fdmgroup.model.User;
import com.lambdaworks.crypto.SCryptUtil;

public class UserDAO {
	
private EntityManager em;
	
	private static final UserDAO userDAO = new UserDAO();
		
	private UserDAO() {
		init();
	}
	
	public static UserDAO getInstance(){
		return userDAO;
	}
	
	public void init(){
		em = DAO.getInstance().getEntityManager();
	}

	public void createUser(User user) {
		EntityTransaction et = em.getTransaction();
		et.begin();
		em.persist(user);
		et.commit();
	}
	
	
	public User getUserUsername(String username) {
		TypedQuery<User> query = em.createNamedQuery("oneUserUsernameOnly", User.class);
		query.setParameter("username_in", username);
		try {
			return query.getSingleResult();
		} catch (NoResultException e){
			return null;
		}
	}
	
	public User getUserEmail(String email) {
		TypedQuery<User> query = em.createNamedQuery("oneUserEmailOnly", User.class);
		query.setParameter("email_in", email);
		try {
			return query.getSingleResult();
		} catch (NoResultException e){
			return null;
		}
	}
	
	public User getUserByID(int id) {
		TypedQuery<User> query = em.createNamedQuery("oneUserIDOnly", User.class);
		query.setParameter("id_in", id);
		try {
			return query.getSingleResult();
		} catch (NoResultException e){
			return null;
		}
	}
	
	public List<User> getAllUsers() {
		TypedQuery<User> query = em.createNamedQuery("allUser", User.class);
		return query.getResultList();
	}
	
	public void updateUser(User user) {
		EntityTransaction et = em.getTransaction();
		et.begin();
		em.merge(user);
		et.commit();
	}
	
	public boolean comparePassword(String inputPassword, String hashedPassword){
		if(SCryptUtil.check(inputPassword, hashedPassword)){
			return true;
		}else{
			return false;
		}
	}
}
