package com.fdmgroup.dao;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.TypedQuery;
import com.fdmgroup.model.TalkToAdmin;

public class TalkToAdminDAO {

	private EntityManager em;
	
	private static final TalkToAdminDAO talkToAdminDAO = new TalkToAdminDAO();
	
	private TalkToAdminDAO() {
		init();
	}
	
	public static TalkToAdminDAO getInstance(){
		return talkToAdminDAO;
	}
	
	public void init(){
		em = DAO.getInstance().getEntityManager();
	}
	
	public void create(TalkToAdmin t) {
		EntityTransaction et = em.getTransaction();
		et.begin();
		em.persist(t);
		et.commit();
	}
}
