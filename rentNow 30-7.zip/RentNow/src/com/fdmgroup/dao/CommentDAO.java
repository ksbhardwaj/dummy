package com.fdmgroup.dao;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.TypedQuery;
import com.fdmgroup.model.Comment;
import com.fdmgroup.model.Post;

public class CommentDAO {

private EntityManager em;
	
	private static final CommentDAO commentDAO = new CommentDAO();
		
	private CommentDAO() {
		init();
	}
	
	public static CommentDAO getInstance(){
		return commentDAO;
	}
	
	public void init(){
		em = DAO.getInstance().getEntityManager();
	}
	
	public void create(Comment t) {
		EntityTransaction et = em.getTransaction();
		et.begin();
		em.persist(t);
		et.commit();
	}
	
	public List<Comment> read(Post post) {
		TypedQuery<Comment> query = em.createNamedQuery("comment.findByPost", Comment.class);
		query.setParameter("post", post);
		return query.getResultList();
	}
}
