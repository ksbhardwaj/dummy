$(document).ready(function() {
	
	$("#submitComment").click(function(e){
		e.preventDefault();
		alert('default');
		var id = $("#getPostId").val();
		$.post("../comment/" + id,
				{addComment: $("textarea#commentBody").val().toString()}, function(responseData) {
					
			if(responseData){
				console.log(responseData);
				//sendSocketMessage("comment added successfully..!");
				//window.location.replace("../../post/user/" + id);
			}
		});
	});
	
});