 
$(document).ready(function() {
	$("#submitMessage").click(function(e){
		e.preventDefault();
		$.post("../../sendmessage/",
			{
			messageBody: $("textarea#addMessage").val().toString(),
			postUserId: $("#postUserId").html()
			}, function(responseData) {
					
			if(responseData.success == "true"){
				$('#messageForm')[0].reset();
				alert(responseData.message);
			}
		});
	});
});