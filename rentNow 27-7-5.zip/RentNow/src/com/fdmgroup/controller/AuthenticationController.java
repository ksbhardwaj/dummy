package com.fdmgroup.controller;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;

import com.fdmgroup.dao.UserDAO;
import com.fdmgroup.model.User;

@Controller
@SessionAttributes(value={"currentUser"}, types={User.class})
public class AuthenticationController {
	
//	@Autowired
	private UserDAO userDao = UserDAO.getInstance();
	
	@RequestMapping(value="/login", method=RequestMethod.GET)
	public String showLogin(Model model, HttpServletRequest request){
		HttpServletRequest httpReq= (HttpServletRequest) request;
		HttpSession session= httpReq.getSession(false);
		
		if(session==null || session.getAttribute("currentUser")==null){
			return "login";			
		} else if (session.getAttribute("currentUser")!=null) {
			User user = (User) session.getAttribute("currentUser");
						
			User foundUser = userDao.getUserUsername(user.getUsername());
			
			if(foundUser!=null && foundUser.getPassword().equals(user.getPassword())){
				model.addAttribute("currentUser", foundUser);
				return "redirect:/dashboard";
			}
		}
		return "login";
	}

	@RequestMapping(value="/login", method=RequestMethod.POST)
	public String processLogin(Model model, @RequestParam String username, @RequestParam String password, HttpServletRequest request){
		User foundUser;
		
		if(username.contains("@")) {
			foundUser = userDao.getUserEmail(username);
		} else {
			foundUser = userDao.getUserUsername(username);
		}

		if(foundUser!=null && userDao.comparePassword(password, foundUser.getPassword())){
			model.addAttribute("currentUser", foundUser);
			request.getSession().setAttribute("currentUser", foundUser);
			return "redirect:/dashboard";
		}
		request.setAttribute("errorMsg", "Invalid Username/Password !");
		model.addAttribute("currentUser", new User());
		return "login";
		
	}
	
	@RequestMapping(value="/logout", method=RequestMethod.GET)
	public String logout(Model model, SessionStatus ss, @ModelAttribute(value="currentUser") User user, HttpServletRequest request){
		ss.setComplete();
		model.addAttribute("currentUser", null);
		HttpSession session= request.getSession();
		session.removeAttribute("currentUser");
		session.invalidate();
		return "forward:/login";
	}

}
