package com.fdmgroup.dao;

import java.io.IOException;
import java.util.List;
import java.util.Scanner;

import com.fdmgroup.model.Post;
import com.fdmgroup.model.User;

public class MainApp {
	private static Scanner sc = new Scanner(System.in);
	UserDAO userDao = UserDAO.getInstance();
	//private static PostDAO postDao = new PostDAO();
	
	private List<User> users;
	
	private int id=-1;
	
	public void switchCase(int option) throws IOException{
		switch(option){    
		case 1:
			System.out.println("Register:");
			System.out.println("Enter Firstname...");
			String firstname = sc.next();
			System.out.println("Enter Lastname...");
			String lastname = sc.next();
			System.out.println("Enter Username...");
			String username = sc.next();
			System.out.println("Enter Email...");
			String email = sc.next();
			System.out.println("Enter Password...");
			String password = sc.next();
			//User user = new User(firstname, lastname, username, email, password, 0);
			//userDao.create(user);
			System.out.println("Successful..!");
			switchCase(2);
		 break;    
		
		case 2:
			System.out.println("Login:");
			System.out.println("Enter username");
			String username1 = sc.next();
			System.out.println("Enter password");
			String password1 = sc.next();
			//users = userDao.login(username1, password1);
			if (users == null){
				System.out.println("Login Failed..!");
				switchCase(1);
			}
			else {
				System.out.println("Login Successful..");
				//switchCase(3);
			}
		 break;
		 
		case 3:
			System.out.println("Welcome to RentNow...!");
			System.out.println("Choose (1: Add New Post 2: View All Posts)");
			int option1 = sc.nextInt();
			switch(option1){
			case 1:
				System.out.println("Add New Post...");
				System.out.println("Enter Available Date...");
				String availableDate = sc.next();
				System.out.println("Enter Category...");
				String category = sc.next();
				System.out.println("Enter Description...");
				String description = sc.next();
				System.out.println("Image Path...");
				String imagePath = "C:/sample_image.jpg";
				
				System.out.println("Address...");
				System.out.println("Enter Unit/Apartment Number...");
				String apartment = sc.next();
				System.out.println("Enter Street Number...");
				String street = sc.next();
				System.out.println("Enter City...");
				String city = sc.next();
				System.out.println("Enter postal...");
				String postal = sc.next();
				
//				Post post = new Post(availableDate, category, description, imagePath, 0, new PostAddress(apartment, street, city, postal), users.get(0));
//				postDao.create(post);
				System.out.println("Successful..!");
				main(null);
				break;
			case 2:
				break;
			default:
				break;
			}
		 break;
		default:
			System.out.println("Wrong Input...!");
			main(null);
		}
	}
	
	public static void main(String[] args) throws IOException {
		
		System.out.println("Choose (1:Register 2:Login)...");
		int option = sc.nextInt();
		
		MainApp app = new MainApp();
		app.switchCase(option);
	}
	
	
}
