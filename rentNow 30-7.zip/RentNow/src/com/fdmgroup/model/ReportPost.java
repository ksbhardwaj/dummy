package com.fdmgroup.model;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "rentnow_reportpost")
@NamedQueries({
	@NamedQuery(name = "reportpost.findAll", query = "SELECT p FROM ReportPost p"),
	@NamedQuery(name = "reportpost.delete", query = "DELETE FROM ReportPost p WHERE p.postid= :postid"),
	@NamedQuery(name = "reportpost.findById", query = "SELECT p FROM ReportPost p WHERE p.postid= :postid")
})
public class ReportPost implements Serializable{


	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="id")
	@SequenceGenerator(name = "my_seq_reportpost", sequenceName="MY_JPA_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="my_seq_reportpost")
	private int id;
	
	@Column(name="postid", nullable=false)
	private int postid;
	
	public ReportPost() {
		super();
	}

	public ReportPost(int postid) {
		super();
		this.postid = postid;
	}

	@Override
	public String toString() {
		return "ReportPost [postid=" + postid + "]";
	}

	public int getPostid() {
		return postid;
	}

	public void setPostid(int postid) {
		this.postid = postid;
	}
	
	
}
