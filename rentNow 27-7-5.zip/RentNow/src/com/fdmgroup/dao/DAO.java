package com.fdmgroup.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class DAO {
	private static DAO dao=null;
	private EntityManagerFactory emf=null;
	private EntityManager em=null;
	
	
	private DAO(){
		init();
	}
	
	private void init(){
		emf=Persistence.createEntityManagerFactory("RentNow");
		em=emf.createEntityManager();
	}
	
	public static DAO getInstance(){
		if(dao==null)
			dao=new DAO();
		
		return dao;
	}
	
	public EntityManager getEntityManager(){
		return em;
	}
}
