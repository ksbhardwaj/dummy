package com.fdmgroup.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;
import org.springframework.web.util.WebUtils;

import com.fdmgroup.model.User;

public class AuthenticationInterceptor extends HandlerInterceptorAdapter {

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {

		System.out.println("Inside authentication interceptor...");
		System.out.println(request.getRequestURL().toString());

		User user = (User) WebUtils.getSessionAttribute(request, "currentUser");


		if (request.getRequestURL().toString().contains(".jsp")) {
			response.sendRedirect("/RentNow/");
			return false;
		}


		if (user == null || user.getUsername() == null){
			response.sendRedirect("/RentNow/");
			return false;
		}

		return true;
	}
}
