$(document).ready(function() {
	$("#reportPost").click(function(e){
		e.preventDefault();
		var id = $('#post-id').html();
		$.post("../spam/" + id,
				{}, function(responseData) {
			if(responseData.success == "true"){
				alert(responseData.message);
			}
		});
	});
});